var classstat__dialog =
[
    [ "stat_dialog", "classstat__dialog.html#a4a77448d9196257a4a5e0aebf02a0ab7", null ],
    [ "~stat_dialog", "classstat__dialog.html#ac628e47d8eb4d3972ec6dbf6f42d6df3", null ]
];