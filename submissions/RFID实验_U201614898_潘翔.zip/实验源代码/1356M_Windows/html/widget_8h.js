var widget_8h =
[
    [ "Widget", "class_widget.html", "class_widget" ],
    [ "COMBOBOX_COUNT", "widget_8h.html#a1d2dbe60aded23affb089e8fa1ea345f", null ],
    [ "CONNECT_BUTTON_COUNT", "widget_8h.html#a8c7377d6ed6b5f2e3d196cda9bd66d91", null ],
    [ "ComboBox_INDEX", "widget_8h.html#a0ef8586ed514a0978fff5a20be649a40", [
      [ "Serial", "widget_8h.html#a0ef8586ed514a0978fff5a20be649a40aab27270f353006b03c91367e05e44b94", null ],
      [ "Baud", "widget_8h.html#a0ef8586ed514a0978fff5a20be649a40ab4ad77bb6360289ef49e9b03a26780ac", null ]
    ] ],
    [ "Connect_Button_INDEX", "widget_8h.html#a15727ed906d8c35acf9e02d4691fcb7d", [
      [ "Connect", "widget_8h.html#a15727ed906d8c35acf9e02d4691fcb7daee552f3150bddbf101d3541c3218010e", null ],
      [ "Disconnect", "widget_8h.html#a15727ed906d8c35acf9e02d4691fcb7dae00c828f4fd9e015e2276d53e9ca5524", null ]
    ] ],
    [ "Tab", "widget_8h.html#a8fe90f207489a0982422faf42ad59f1c", [
      [ "Borrow", "widget_8h.html#a8fe90f207489a0982422faf42ad59f1ca6b7595015ca76661d536c5424b52510c", null ],
      [ "Return", "widget_8h.html#a8fe90f207489a0982422faf42ad59f1ca9fa8a5a1e10fdeafbb823a1c31fbd491", null ],
      [ "User", "widget_8h.html#a8fe90f207489a0982422faf42ad59f1cae168fb880dc0042ac28438e1875e41d3", null ],
      [ "Books", "widget_8h.html#a8fe90f207489a0982422faf42ad59f1ca59c5cb5178a7b549bd2e592108d13366", null ]
    ] ]
];