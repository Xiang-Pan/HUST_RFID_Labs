var hierarchy =
[
    [ "QDialog", null, [
      [ "stat_dialog", "classstat__dialog.html", null ]
    ] ],
    [ "QObject", null, [
      [ "Tools", "class_tools.html", null ]
    ] ],
    [ "QThread", null, [
      [ "UHF_Thread", "class_u_h_f___thread.html", null ]
    ] ],
    [ "QWidget", null, [
      [ "BooksManage", "class_books_manage.html", null ],
      [ "Borrow_Return", "class_borrow___return.html", null ],
      [ "Record", "class_record.html", null ],
      [ "stat_form", "classstat__form.html", null ],
      [ "UserManage", "class_user_manage.html", null ],
      [ "Widget", "class_widget.html", null ]
    ] ],
    [ "Sqlite", "class_sqlite.html", null ]
];