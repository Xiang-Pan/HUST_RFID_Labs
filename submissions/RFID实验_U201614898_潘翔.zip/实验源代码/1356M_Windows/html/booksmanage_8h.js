var booksmanage_8h =
[
    [ "BooksManage", "class_books_manage.html", "class_books_manage" ],
    [ "Button_Count_BOOKS", "booksmanage_8h.html#a1f031c616a6edfa38e89dfb16a4f5a5e", null ],
    [ "Edit_Count_BOOKS", "booksmanage_8h.html#a37e6a98d7cb44866bfdff08467fbbab1", null ],
    [ "Label_Count_BOOKS", "booksmanage_8h.html#a575ef603f6be7bd11518983b660df624", null ],
    [ "Table_Column_BOOKS", "booksmanage_8h.html#a091d5b951bf85f7aace3bd3f84722aa2", null ],
    [ "Button_Index_Books", "booksmanage_8h.html#ab4b5633c79827c025033c1d663da9a9c", [
      [ "Add_Books", "booksmanage_8h.html#ab4b5633c79827c025033c1d663da9a9ca34141707a4eed82846ad64a73605594d", null ],
      [ "Delete_Books", "booksmanage_8h.html#ab4b5633c79827c025033c1d663da9a9cadbcc4677ad5683b5ac42cccf7d9335c4", null ],
      [ "Updata_Books", "booksmanage_8h.html#ab4b5633c79827c025033c1d663da9a9ca1d7751c07ca0f70ee04e29000a6aa7c6", null ],
      [ "Select_Books", "booksmanage_8h.html#ab4b5633c79827c025033c1d663da9a9ca9685c369d16812a8f3cb9f0d72708d99", null ]
    ] ],
    [ "Edit_Index_Books", "booksmanage_8h.html#a21d63ec8fb784015524586c62935ac7c", [
      [ "ID_Books", "booksmanage_8h.html#a21d63ec8fb784015524586c62935ac7ca92fe3b4262d2ce51825a32af3277e58c", null ],
      [ "Name_Books", "booksmanage_8h.html#a21d63ec8fb784015524586c62935ac7cac07bf74e7a7eda36dfa6984b718c5df7", null ],
      [ "Author_Books", "booksmanage_8h.html#a21d63ec8fb784015524586c62935ac7cacf85ea93685f87a571cfab3c4db0f884", null ],
      [ "PublishingHouse_Books", "booksmanage_8h.html#a21d63ec8fb784015524586c62935ac7cad3f729e58215f4c00d20a4384d78d08c", null ],
      [ "Count_Books", "booksmanage_8h.html#a21d63ec8fb784015524586c62935ac7ca46bd04a0365479757f00ca412e5f49e0", null ],
      [ "Residue_Books", "booksmanage_8h.html#a21d63ec8fb784015524586c62935ac7ca4d75f9a6c1c7a6f8cdec9e733656277e", null ],
      [ "Borrow_Days", "booksmanage_8h.html#a21d63ec8fb784015524586c62935ac7caa272d236ca47a57f9dccb821cbea59cb", null ]
    ] ]
];