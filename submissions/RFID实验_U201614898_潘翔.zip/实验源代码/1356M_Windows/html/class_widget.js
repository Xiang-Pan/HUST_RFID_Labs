var class_widget =
[
    [ "Widget", "class_widget.html#a29531c7f141e461322981b3b579d4590", null ],
    [ "~Widget", "class_widget.html#aa24f66bcbaaec6d458b0980e8c8eae65", null ],
    [ "Get_Info", "class_widget.html#a0b1204d50863ef19c6ed3e39ab455d25", null ],
    [ "Get_User_Info", "class_widget.html#a349b456bf6a673058ef7449e44866e90", null ],
    [ "Get_User_Record", "class_widget.html#a743bf0399f3c3972556443c2576386be", null ],
    [ "getSerialName", "class_widget.html#afb97de9294ffdbb2c64ed1f96aea9261", null ],
    [ "Init_Connect_Operation_Box", "class_widget.html#a73ede9961382ea942361e9845fa11aa0", null ],
    [ "RefreshWidget", "class_widget.html#a07120b41431597f8e2d0eb86098a6ba7", null ],
    [ "Set_Tab", "class_widget.html#ac611086a6f74fe7bab712f23ab7126d8", null ],
    [ "Set_Title", "class_widget.html#a5323ca5c4124c0d187a2f1398ef48844", null ],
    [ "Set_User_Record", "class_widget.html#a97f2c2eda030b7236e02c5f5e10c8926", null ],
    [ "setSlot", "class_widget.html#ac60c5a62bc3197fbc7ade8f40df70c70", null ],
    [ "Uhf_Connect_Button_Click", "class_widget.html#acceb5443a97ee9023250cda33f183bef", null ],
    [ "Uhf_Disconnect_Button_Click", "class_widget.html#a0186f9125495a90a0166280d932ae831", null ],
    [ "cmd", "class_widget.html#a08095644a5511e36fc9e52228e79dc81", null ]
];