var class_record =
[
    [ "Record", "class_record.html#af85c9f8ff0abca5ee43b4a024557f38a", null ],
    [ "Clear", "class_record.html#af70466cb248483ed2a32fb5a48a83cac", null ],
    [ "ClearEdit", "class_record.html#ad33ee61f2d53795e3090426aa3ba6af0", null ],
    [ "delete_record", "class_record.html#a4c0e51ba399bdec6c9630b193914e7fb", null ],
    [ "get_table_line", "class_record.html#a89ae432465b31de8a27e2fe8e929b62a", null ],
    [ "select_record", "class_record.html#a5fdd1f2b39a2de50ec73b57bb24bb8dc", null ],
    [ "SetCard", "class_record.html#ac08eeade2dbe9fd49ba7d508865f2ab1", null ],
    [ "SetSlot", "class_record.html#acc7b3423b809a15465c21f51353392d5", null ],
    [ "ShowTable", "class_record.html#aa1e340f0b1a776819d30d23c1424cbd2", null ]
];