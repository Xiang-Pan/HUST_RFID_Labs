var classstat__form =
[
    [ "stat_form", "classstat__form.html#af282c982608f55b942190fd743d858bc", null ],
    [ "~stat_form", "classstat__form.html#a7a0e7f191915a1fcf7e2043bc39448b0", null ]
];