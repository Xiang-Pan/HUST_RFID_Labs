var usermanage_8h =
[
    [ "UserManage", "class_user_manage.html", "class_user_manage" ],
    [ "Button_Count_USER", "usermanage_8h.html#abdbae7de651447e47cae67dd821a74fb", null ],
    [ "Edit_Count_USER", "usermanage_8h.html#ad566d7b39279371cb1144d506523f783", null ],
    [ "Label_Count_USER", "usermanage_8h.html#abc2d44d68135265538a4352d526067e8", null ],
    [ "Table_Column_USER", "usermanage_8h.html#a7940e54e63a4f960223305c5c099f294", null ],
    [ "Button_Index_User", "usermanage_8h.html#a69a80e76e8baa099f1467dd26ee379c8", [
      [ "Add_User", "usermanage_8h.html#a69a80e76e8baa099f1467dd26ee379c8ac2c92b7ef1eecfa68557f40613457cd2", null ],
      [ "Loss_User", "usermanage_8h.html#a69a80e76e8baa099f1467dd26ee379c8a30b92c2e1ac5ea0c3e22e7654e7fb10e", null ],
      [ "Delete_User", "usermanage_8h.html#a69a80e76e8baa099f1467dd26ee379c8a0d6e1ab36a327fc6908176c5e2c7bd66", null ],
      [ "Updata_User", "usermanage_8h.html#a69a80e76e8baa099f1467dd26ee379c8a9e507cec8e51e7523acfc5770d4743a4", null ],
      [ "Select_User", "usermanage_8h.html#a69a80e76e8baa099f1467dd26ee379c8aecf7084b6062d6d87926aafbde042633", null ]
    ] ],
    [ "Edit_Index_User", "usermanage_8h.html#a2df23cdebda8cfc47c19c4ce462cd14d", [
      [ "ID_User", "usermanage_8h.html#a2df23cdebda8cfc47c19c4ce462cd14da477d9a295bb7f333b54c9fb98fe59902", null ],
      [ "Name_User", "usermanage_8h.html#a2df23cdebda8cfc47c19c4ce462cd14daa5fd0882e5994b4a97f11613dfe84b1e", null ],
      [ "Gender_User", "usermanage_8h.html#a2df23cdebda8cfc47c19c4ce462cd14dabd9460fb478e3eab5fdf677d2b98703a", null ],
      [ "Age_User", "usermanage_8h.html#a2df23cdebda8cfc47c19c4ce462cd14daa6b52a3ec7307573ca20e874c04de60d", null ],
      [ "Tele_User", "usermanage_8h.html#a2df23cdebda8cfc47c19c4ce462cd14dafc9fd03a04034749b2c96ab755603b4e", null ],
      [ "Status_User", "usermanage_8h.html#a2df23cdebda8cfc47c19c4ce462cd14da59bdd3fc4e2e20fdf701754a353ad975", null ]
    ] ]
];