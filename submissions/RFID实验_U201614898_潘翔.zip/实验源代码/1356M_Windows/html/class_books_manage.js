var class_books_manage =
[
    [ "BooksManage", "class_books_manage.html#adc44f2312ab4d2cd48868ff923fa8861", null ],
    [ "add_books", "class_books_manage.html#a39c7bdd07e0af93379e1270becd8525c", null ],
    [ "Clear", "class_books_manage.html#a8388b6b8547cc759a9976c1a567aab0a", null ],
    [ "ClearEdit", "class_books_manage.html#aa5b813a7fb68aa61a143f84c87699c83", null ],
    [ "delete_books", "class_books_manage.html#ae8adc7f70a2e95f5a5991137e11a18ae", null ],
    [ "get_table_line", "class_books_manage.html#a0269967278f32edfd3f14ccff0a41715", null ],
    [ "select_books", "class_books_manage.html#ab2a76473efc3b68a9e1589cca6ab615d", null ],
    [ "SetCard", "class_books_manage.html#a009c231a6f8976be927b7acfdc4d4591", null ],
    [ "SetSlot", "class_books_manage.html#a0ee0a3e432c7789497c17758d1f82fdf", null ],
    [ "ShowTable", "class_books_manage.html#abbacf5e112bdee769aaa4d22c0e14744", null ],
    [ "updata_books", "class_books_manage.html#aba42cfe2129f1b92dab5a08e1f73ee07", null ]
];