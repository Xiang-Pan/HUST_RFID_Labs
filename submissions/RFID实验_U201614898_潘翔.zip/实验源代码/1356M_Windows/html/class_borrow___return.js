var class_borrow___return =
[
    [ "Borrow_Return", "class_borrow___return.html#a60ee7fbb6b774305fbd655bd362572c5", null ],
    [ "checkReturnDate", "class_borrow___return.html#a1a2d49b2df8463373e60506f77005e64", null ],
    [ "Clear", "class_borrow___return.html#a65b8b7b7c224f0747c4330fb9aa6fdce", null ],
    [ "cycle", "class_borrow___return.html#a52dd74c4080e36657cf122c7c8569a89", null ],
    [ "set_record", "class_borrow___return.html#a8e6d3fb8c8fcab43ff158d5a0a1d7f40", null ],
    [ "SetInfo", "class_borrow___return.html#afd3bfd00077c0704c8b26f8e4254e176", null ],
    [ "ShowTable", "class_borrow___return.html#a061bb2484dacfe92218acb7d6e9494e5", null ],
    [ "last_notification_ID", "class_borrow___return.html#ab0439e8a8c1c061b43bc4e57d8a4a491", null ]
];