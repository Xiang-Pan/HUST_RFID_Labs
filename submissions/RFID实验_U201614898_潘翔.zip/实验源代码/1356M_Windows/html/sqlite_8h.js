var sqlite_8h =
[
    [ "Sqlite", "class_sqlite.html", "class_sqlite" ],
    [ "DATABASE", "sqlite_8h.html#a39dc88d73783e112dbfcf98adbdbefa6", null ]
];