var borrow__return_8cpp =
[
    [ "canBorrow", "borrow__return_8cpp.html#ac3026214e00f622293281691a249ea7a", null ]
];