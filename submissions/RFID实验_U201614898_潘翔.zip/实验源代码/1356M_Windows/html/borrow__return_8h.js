var borrow__return_8h =
[
    [ "Borrow_Return", "class_borrow___return.html", "class_borrow___return" ],
    [ "Edit_Count_BORROW_RETURN", "borrow__return_8h.html#a35b2fb4ddb399d5c884c4199466d78ce", null ],
    [ "Label_Count_BORROW_RETURN", "borrow__return_8h.html#af38a41a002c7bb91d4bcdd0facb02fbe", null ],
    [ "Table_Column_BORROW_RETURN", "borrow__return_8h.html#a6ae252588145ed1bbb7f80c4ebf10863", null ],
    [ "Edit_Index_User_Borrow", "borrow__return_8h.html#a39b7bc4d9991f592ed32e4dbc35fe7c2", [
      [ "CardId_User_Borrow", "borrow__return_8h.html#a39b7bc4d9991f592ed32e4dbc35fe7c2a7ff05eea2065332c4c354bb65087786b", null ],
      [ "Name_User_Borrow", "borrow__return_8h.html#a39b7bc4d9991f592ed32e4dbc35fe7c2a257313c20849d98db5c9a0591f48a98e", null ],
      [ "Gender_User_Borrow", "borrow__return_8h.html#a39b7bc4d9991f592ed32e4dbc35fe7c2afd2b76225a750d5f650d9a428253a79c", null ],
      [ "Age_User_Borrow", "borrow__return_8h.html#a39b7bc4d9991f592ed32e4dbc35fe7c2a2c2646d9845e8926f3081cbcad573f99", null ]
    ] ]
];