var annotated_dup =
[
    [ "BooksManage", "class_books_manage.html", "class_books_manage" ],
    [ "Borrow_Return", "class_borrow___return.html", "class_borrow___return" ],
    [ "Record", "class_record.html", "class_record" ],
    [ "Sqlite", "class_sqlite.html", "class_sqlite" ],
    [ "stat_dialog", "classstat__dialog.html", "classstat__dialog" ],
    [ "stat_form", "classstat__form.html", "classstat__form" ],
    [ "Tools", "class_tools.html", "class_tools" ],
    [ "UHF_Thread", "class_u_h_f___thread.html", "class_u_h_f___thread" ],
    [ "UserManage", "class_user_manage.html", "class_user_manage" ],
    [ "Widget", "class_widget.html", "class_widget" ]
];