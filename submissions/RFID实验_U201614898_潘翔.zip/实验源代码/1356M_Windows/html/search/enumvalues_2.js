var searchData=
[
  ['cardid_5fuser_5fborrow',['CardId_User_Borrow',['../borrow__return_8h.html#a39b7bc4d9991f592ed32e4dbc35fe7c2a7ff05eea2065332c4c354bb65087786b',1,'borrow_return.h']]],
  ['connect',['Connect',['../widget_8h.html#a15727ed906d8c35acf9e02d4691fcb7daee552f3150bddbf101d3541c3218010e',1,'widget.h']]],
  ['count_5fbooks',['Count_Books',['../booksmanage_8h.html#a21d63ec8fb784015524586c62935ac7ca46bd04a0365479757f00ca412e5f49e0',1,'booksmanage.h']]]
];
