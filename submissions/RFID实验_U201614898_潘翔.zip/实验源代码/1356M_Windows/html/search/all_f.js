var searchData=
[
  ['widget',['Widget',['../class_widget.html',1,'Widget'],['../class_widget.html#a29531c7f141e461322981b3b579d4590',1,'Widget::Widget()']]],
  ['widget_2ecpp',['widget.cpp',['../widget_8cpp.html',1,'']]],
  ['widget_2eh',['widget.h',['../widget_8h.html',1,'']]]
];
