var searchData=
[
  ['combobox_5fcount',['COMBOBOX_COUNT',['../widget_8h.html#a1d2dbe60aded23affb089e8fa1ea345f',1,'widget.h']]],
  ['connect_5fbutton_5fcount',['CONNECT_BUTTON_COUNT',['../widget_8h.html#a8c7377d6ed6b5f2e3d196cda9bd66d91',1,'widget.h']]]
];
