var searchData=
[
  ['add_5fbooks',['add_books',['../class_books_manage.html#a39c7bdd07e0af93379e1270becd8525c',1,'BooksManage::add_books()'],['../booksmanage_8h.html#ab4b5633c79827c025033c1d663da9a9ca34141707a4eed82846ad64a73605594d',1,'Add_Books():&#160;booksmanage.h']]],
  ['add_5fuser',['add_user',['../class_user_manage.html#a7058bbb981e4c6b3064c3e5e334ac700',1,'UserManage::add_user()'],['../usermanage_8h.html#a69a80e76e8baa099f1467dd26ee379c8ac2c92b7ef1eecfa68557f40613457cd2',1,'Add_User():&#160;usermanage.h']]],
  ['age_5fuser',['Age_User',['../usermanage_8h.html#a2df23cdebda8cfc47c19c4ce462cd14daa6b52a3ec7307573ca20e874c04de60d',1,'usermanage.h']]],
  ['age_5fuser_5fborrow',['Age_User_Borrow',['../borrow__return_8h.html#a39b7bc4d9991f592ed32e4dbc35fe7c2a2c2646d9845e8926f3081cbcad573f99',1,'borrow_return.h']]],
  ['author_5fbooks',['Author_Books',['../booksmanage_8h.html#a21d63ec8fb784015524586c62935ac7cacf85ea93685f87a571cfab3c4db0f884',1,'booksmanage.h']]]
];
