var searchData=
[
  ['id_5fbooks',['ID_Books',['../booksmanage_8h.html#a21d63ec8fb784015524586c62935ac7ca92fe3b4262d2ce51825a32af3277e58c',1,'booksmanage.h']]],
  ['id_5fuser',['ID_User',['../usermanage_8h.html#a2df23cdebda8cfc47c19c4ce462cd14da477d9a295bb7f333b54c9fb98fe59902',1,'usermanage.h']]]
];
