var searchData=
[
  ['residue_5fbooks',['Residue_Books',['../booksmanage_8h.html#a21d63ec8fb784015524586c62935ac7ca4d75f9a6c1c7a6f8cdec9e733656277e',1,'booksmanage.h']]],
  ['return',['Return',['../widget_8h.html#a8fe90f207489a0982422faf42ad59f1ca9fa8a5a1e10fdeafbb823a1c31fbd491',1,'widget.h']]]
];
