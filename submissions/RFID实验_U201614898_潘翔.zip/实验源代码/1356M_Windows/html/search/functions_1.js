var searchData=
[
  ['booksmanage',['BooksManage',['../class_books_manage.html#adc44f2312ab4d2cd48868ff923fa8861',1,'BooksManage']]],
  ['borrow_5freturn',['Borrow_Return',['../class_borrow___return.html#a60ee7fbb6b774305fbd655bd362572c5',1,'Borrow_Return']]]
];
