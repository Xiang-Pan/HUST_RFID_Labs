var searchData=
[
  ['add_5fbooks',['add_books',['../class_books_manage.html#a39c7bdd07e0af93379e1270becd8525c',1,'BooksManage']]],
  ['add_5fuser',['add_user',['../class_user_manage.html#a7058bbb981e4c6b3064c3e5e334ac700',1,'UserManage']]]
];
