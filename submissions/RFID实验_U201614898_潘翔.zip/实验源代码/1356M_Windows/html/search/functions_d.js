var searchData=
[
  ['widget',['Widget',['../class_widget.html#a29531c7f141e461322981b3b579d4590',1,'Widget']]]
];
