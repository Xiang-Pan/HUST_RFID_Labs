var searchData=
[
  ['label_5fcount_5fbooks',['Label_Count_BOOKS',['../booksmanage_8h.html#a575ef603f6be7bd11518983b660df624',1,'booksmanage.h']]],
  ['label_5fcount_5fborrow_5freturn',['Label_Count_BORROW_RETURN',['../borrow__return_8h.html#af38a41a002c7bb91d4bcdd0facb02fbe',1,'borrow_return.h']]],
  ['label_5fcount_5frecord',['Label_Count_Record',['../record_8h.html#add5f3d7c7526d68cc7cff1d173adf1a1',1,'record.h']]],
  ['label_5fcount_5fuser',['Label_Count_USER',['../usermanage_8h.html#abc2d44d68135265538a4352d526067e8',1,'usermanage.h']]]
];
