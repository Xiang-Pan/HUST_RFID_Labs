var searchData=
[
  ['edit_5fcount_5fbooks',['Edit_Count_BOOKS',['../booksmanage_8h.html#a37e6a98d7cb44866bfdff08467fbbab1',1,'booksmanage.h']]],
  ['edit_5fcount_5fborrow_5freturn',['Edit_Count_BORROW_RETURN',['../borrow__return_8h.html#a35b2fb4ddb399d5c884c4199466d78ce',1,'borrow_return.h']]],
  ['edit_5fcount_5frecord',['Edit_Count_Record',['../record_8h.html#a02fbceef67a55fc0f21a7b2516ff47b3',1,'record.h']]],
  ['edit_5fcount_5fuser',['Edit_Count_USER',['../usermanage_8h.html#ad566d7b39279371cb1144d506523f783',1,'usermanage.h']]],
  ['edit_5findex_5fbooks',['Edit_Index_Books',['../booksmanage_8h.html#a21d63ec8fb784015524586c62935ac7c',1,'booksmanage.h']]],
  ['edit_5findex_5fuser',['Edit_Index_User',['../usermanage_8h.html#a2df23cdebda8cfc47c19c4ce462cd14d',1,'usermanage.h']]],
  ['edit_5findex_5fuser_5fborrow',['Edit_Index_User_Borrow',['../borrow__return_8h.html#a39b7bc4d9991f592ed32e4dbc35fe7c2',1,'borrow_return.h']]],
  ['execsql',['ExecSQL',['../class_sqlite.html#a3d4be952cdb19b674a80dacd78e2873a',1,'Sqlite']]],
  ['export_5ftable',['export_table',['../class_tools.html#af6c4eaadfb21ee231cbc4d6384250629',1,'Tools']]]
];
