var searchData=
[
  ['widget',['Widget',['../class_widget.html',1,'']]]
];
