var indexSectionsWithContent =
{
  0: "abcdegilmnprstuw~",
  1: "brstuw",
  2: "u",
  3: "bmrstuw",
  4: "abcdegilmrstuw~",
  5: "cln",
  6: "bcelt",
  7: "abcdgilnprstu",
  8: "bcdelt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "enums",
  7: "enumvalues",
  8: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros"
};

