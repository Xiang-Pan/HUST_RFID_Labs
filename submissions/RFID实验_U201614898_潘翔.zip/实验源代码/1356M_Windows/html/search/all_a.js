var searchData=
[
  ['publishinghouse_5fbooks',['PublishingHouse_Books',['../booksmanage_8h.html#a21d63ec8fb784015524586c62935ac7cad3f729e58215f4c00d20a4384d78d08c',1,'booksmanage.h']]]
];
