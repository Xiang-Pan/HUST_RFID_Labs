var searchData=
[
  ['name_5fbooks',['Name_Books',['../booksmanage_8h.html#a21d63ec8fb784015524586c62935ac7cac07bf74e7a7eda36dfa6984b718c5df7',1,'booksmanage.h']]],
  ['name_5fuser',['Name_User',['../usermanage_8h.html#a2df23cdebda8cfc47c19c4ce462cd14daa5fd0882e5994b4a97f11613dfe84b1e',1,'usermanage.h']]],
  ['name_5fuser_5fborrow',['Name_User_Borrow',['../borrow__return_8h.html#a39b7bc4d9991f592ed32e4dbc35fe7c2a257313c20849d98db5c9a0591f48a98e',1,'borrow_return.h']]],
  ['nrunflag',['nRunFlag',['../class_u_h_f___thread.html#ab40811b93c5e8b31c4f40cc79139e504',1,'UHF_Thread']]]
];
