var searchData=
[
  ['tab',['Tab',['../widget_8h.html#a8fe90f207489a0982422faf42ad59f1c',1,'widget.h']]]
];
