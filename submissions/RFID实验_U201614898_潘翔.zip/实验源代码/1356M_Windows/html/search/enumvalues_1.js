var searchData=
[
  ['baud',['Baud',['../widget_8h.html#a0ef8586ed514a0978fff5a20be649a40ab4ad77bb6360289ef49e9b03a26780ac',1,'widget.h']]],
  ['bookid_5frecord',['BookID_Record',['../record_8h.html#a234190da5e2f630e0dcfb32bba809790a51e0dee3493b6aed0840faf460eb57a0',1,'record.h']]],
  ['books',['Books',['../widget_8h.html#a8fe90f207489a0982422faf42ad59f1ca59c5cb5178a7b549bd2e592108d13366',1,'widget.h']]],
  ['borrow',['Borrow',['../widget_8h.html#a8fe90f207489a0982422faf42ad59f1ca6b7595015ca76661d536c5424b52510c',1,'widget.h']]],
  ['borrow_5fdays',['Borrow_Days',['../booksmanage_8h.html#a21d63ec8fb784015524586c62935ac7caa272d236ca47a57f9dccb821cbea59cb',1,'booksmanage.h']]]
];
