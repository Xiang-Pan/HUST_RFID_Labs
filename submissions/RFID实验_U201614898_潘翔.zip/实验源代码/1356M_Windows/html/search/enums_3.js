var searchData=
[
  ['label_5findex_5frecord',['Label_Index_Record',['../record_8h.html#a234190da5e2f630e0dcfb32bba809790',1,'record.h']]]
];
