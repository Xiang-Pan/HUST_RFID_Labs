var searchData=
[
  ['edit_5findex_5fbooks',['Edit_Index_Books',['../booksmanage_8h.html#a21d63ec8fb784015524586c62935ac7c',1,'booksmanage.h']]],
  ['edit_5findex_5fuser',['Edit_Index_User',['../usermanage_8h.html#a2df23cdebda8cfc47c19c4ce462cd14d',1,'usermanage.h']]],
  ['edit_5findex_5fuser_5fborrow',['Edit_Index_User_Borrow',['../borrow__return_8h.html#a39b7bc4d9991f592ed32e4dbc35fe7c2',1,'borrow_return.h']]]
];
