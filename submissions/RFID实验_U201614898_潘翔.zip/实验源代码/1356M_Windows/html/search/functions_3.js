var searchData=
[
  ['delete',['Delete',['../class_sqlite.html#a772711beeceff7a567192e19abccfed4',1,'Sqlite']]],
  ['delete_5fbooks',['delete_books',['../class_books_manage.html#ae8adc7f70a2e95f5a5991137e11a18ae',1,'BooksManage']]],
  ['delete_5frecord',['delete_record',['../class_record.html#a4c0e51ba399bdec6c9630b193914e7fb',1,'Record']]],
  ['delete_5fuser',['delete_user',['../class_user_manage.html#a254765c27c79b94370dd9f1e44551355',1,'UserManage']]],
  ['deletebooks',['DeleteBooks',['../class_sqlite.html#a8a83c22e036086edf84758fb0f6cfc56',1,'Sqlite']]],
  ['deleterecord',['DeleteRecord',['../class_sqlite.html#aa120de86db20f42a61a5c2eae9ad6b89',1,'Sqlite']]],
  ['deleteuser',['DeleteUser',['../class_sqlite.html#af2b581d800d01e1f1281d98ec1341ddd',1,'Sqlite']]]
];
