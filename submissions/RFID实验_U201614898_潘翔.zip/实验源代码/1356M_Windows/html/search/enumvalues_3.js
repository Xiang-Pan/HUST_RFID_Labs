var searchData=
[
  ['delete_5fbooks',['Delete_Books',['../booksmanage_8h.html#ab4b5633c79827c025033c1d663da9a9cadbcc4677ad5683b5ac42cccf7d9335c4',1,'booksmanage.h']]],
  ['delete_5frecord',['Delete_Record',['../record_8h.html#a1c4b953546dc96c53ceec29f579db8caac3a7170ec3e5d9550284fcb777994ab5',1,'record.h']]],
  ['delete_5fuser',['Delete_User',['../usermanage_8h.html#a69a80e76e8baa099f1467dd26ee379c8a0d6e1ab36a327fc6908176c5e2c7bd66',1,'usermanage.h']]],
  ['disconnect',['Disconnect',['../widget_8h.html#a15727ed906d8c35acf9e02d4691fcb7dae00c828f4fd9e015e2276d53e9ca5524',1,'widget.h']]]
];
