var searchData=
[
  ['gender_5fuser',['Gender_User',['../usermanage_8h.html#a2df23cdebda8cfc47c19c4ce462cd14dabd9460fb478e3eab5fdf677d2b98703a',1,'usermanage.h']]],
  ['gender_5fuser_5fborrow',['Gender_User_Borrow',['../borrow__return_8h.html#a39b7bc4d9991f592ed32e4dbc35fe7c2afd2b76225a750d5f650d9a428253a79c',1,'borrow_return.h']]]
];
