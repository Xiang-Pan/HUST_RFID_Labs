var searchData=
[
  ['database',['DATABASE',['../sqlite_8h.html#a39dc88d73783e112dbfcf98adbdbefa6',1,'sqlite.h']]],
  ['delete',['Delete',['../class_sqlite.html#a772711beeceff7a567192e19abccfed4',1,'Sqlite']]],
  ['delete_5fbooks',['delete_books',['../class_books_manage.html#ae8adc7f70a2e95f5a5991137e11a18ae',1,'BooksManage::delete_books()'],['../booksmanage_8h.html#ab4b5633c79827c025033c1d663da9a9cadbcc4677ad5683b5ac42cccf7d9335c4',1,'Delete_Books():&#160;booksmanage.h']]],
  ['delete_5frecord',['delete_record',['../class_record.html#a4c0e51ba399bdec6c9630b193914e7fb',1,'Record::delete_record()'],['../record_8h.html#a1c4b953546dc96c53ceec29f579db8caac3a7170ec3e5d9550284fcb777994ab5',1,'Delete_Record():&#160;record.h']]],
  ['delete_5fuser',['delete_user',['../class_user_manage.html#a254765c27c79b94370dd9f1e44551355',1,'UserManage::delete_user()'],['../usermanage_8h.html#a69a80e76e8baa099f1467dd26ee379c8a0d6e1ab36a327fc6908176c5e2c7bd66',1,'Delete_User():&#160;usermanage.h']]],
  ['deletebooks',['DeleteBooks',['../class_sqlite.html#a8a83c22e036086edf84758fb0f6cfc56',1,'Sqlite']]],
  ['deleterecord',['DeleteRecord',['../class_sqlite.html#aa120de86db20f42a61a5c2eae9ad6b89',1,'Sqlite']]],
  ['deleteuser',['DeleteUser',['../class_sqlite.html#af2b581d800d01e1f1281d98ec1341ddd',1,'Sqlite']]],
  ['disconnect',['Disconnect',['../widget_8h.html#a15727ed906d8c35acf9e02d4691fcb7dae00c828f4fd9e015e2276d53e9ca5524',1,'widget.h']]]
];
