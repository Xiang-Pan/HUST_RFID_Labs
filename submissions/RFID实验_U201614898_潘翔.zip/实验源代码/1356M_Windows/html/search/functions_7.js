var searchData=
[
  ['lossorreget_5fuser',['lossOrReget_user',['../class_user_manage.html#a82a9b76e62d1d7383e264019066082b8',1,'UserManage']]]
];
