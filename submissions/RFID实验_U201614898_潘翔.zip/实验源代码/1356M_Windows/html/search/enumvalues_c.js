var searchData=
[
  ['updata_5fbooks',['Updata_Books',['../booksmanage_8h.html#ab4b5633c79827c025033c1d663da9a9ca1d7751c07ca0f70ee04e29000a6aa7c6',1,'booksmanage.h']]],
  ['updata_5fuser',['Updata_User',['../usermanage_8h.html#a69a80e76e8baa099f1467dd26ee379c8a9e507cec8e51e7523acfc5770d4743a4',1,'usermanage.h']]],
  ['user',['User',['../widget_8h.html#a8fe90f207489a0982422faf42ad59f1cae168fb880dc0042ac28438e1875e41d3',1,'widget.h']]],
  ['userid_5frecord',['UserID_Record',['../record_8h.html#a234190da5e2f630e0dcfb32bba809790ab7daecabbb1b9963e5075504f5e9b865',1,'record.h']]]
];
