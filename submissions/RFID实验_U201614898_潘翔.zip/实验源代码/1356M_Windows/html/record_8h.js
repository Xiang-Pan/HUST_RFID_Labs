var record_8h =
[
    [ "Record", "class_record.html", "class_record" ],
    [ "Button_Count_Record", "record_8h.html#a4d319c985ecf15ec7ce151eea6e5f25e", null ],
    [ "Edit_Count_Record", "record_8h.html#a02fbceef67a55fc0f21a7b2516ff47b3", null ],
    [ "Label_Count_Record", "record_8h.html#add5f3d7c7526d68cc7cff1d173adf1a1", null ],
    [ "Table_Column_Record", "record_8h.html#ab90e1a03cbe5e121060bc70a4a9c7fb6", null ],
    [ "Button_Index_Record", "record_8h.html#a1c4b953546dc96c53ceec29f579db8ca", [
      [ "Select_Record", "record_8h.html#a1c4b953546dc96c53ceec29f579db8caa8d8f87e6cb248357ec406147b65d4c9b", null ],
      [ "Delete_Record", "record_8h.html#a1c4b953546dc96c53ceec29f579db8caac3a7170ec3e5d9550284fcb777994ab5", null ]
    ] ],
    [ "Label_Index_Record", "record_8h.html#a234190da5e2f630e0dcfb32bba809790", [
      [ "UserID_Record", "record_8h.html#a234190da5e2f630e0dcfb32bba809790ab7daecabbb1b9963e5075504f5e9b865", null ],
      [ "BookID_Record", "record_8h.html#a234190da5e2f630e0dcfb32bba809790a51e0dee3493b6aed0840faf460eb57a0", null ]
    ] ]
];