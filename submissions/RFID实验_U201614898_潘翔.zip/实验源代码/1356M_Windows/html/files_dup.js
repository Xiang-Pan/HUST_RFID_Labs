var files_dup =
[
    [ "booksmanage.cpp", "booksmanage_8cpp.html", null ],
    [ "booksmanage.h", "booksmanage_8h.html", "booksmanage_8h" ],
    [ "borrow_return.cpp", "borrow__return_8cpp.html", "borrow__return_8cpp" ],
    [ "borrow_return.h", "borrow__return_8h.html", "borrow__return_8h" ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "record.cpp", "record_8cpp.html", "record_8cpp" ],
    [ "record.h", "record_8h.html", "record_8h" ],
    [ "sqlite.cpp", "sqlite_8cpp.html", null ],
    [ "sqlite.h", "sqlite_8h.html", "sqlite_8h" ],
    [ "stat_dialog.cpp", "stat__dialog_8cpp.html", null ],
    [ "stat_dialog.h", "stat__dialog_8h.html", [
      [ "stat_dialog", "classstat__dialog.html", "classstat__dialog" ]
    ] ],
    [ "stat_form.cpp", "stat__form_8cpp.html", null ],
    [ "stat_form.h", "stat__form_8h.html", [
      [ "stat_form", "classstat__form.html", "classstat__form" ]
    ] ],
    [ "tools.cpp", "tools_8cpp.html", null ],
    [ "tools.h", "tools_8h.html", [
      [ "Tools", "class_tools.html", "class_tools" ]
    ] ],
    [ "uhf_thread.cpp", "uhf__thread_8cpp.html", "uhf__thread_8cpp" ],
    [ "uhf_thread.h", "uhf__thread_8h.html", [
      [ "UHF_Thread", "class_u_h_f___thread.html", "class_u_h_f___thread" ]
    ] ],
    [ "usermanage.cpp", "usermanage_8cpp.html", null ],
    [ "usermanage.h", "usermanage_8h.html", "usermanage_8h" ],
    [ "widget.cpp", "widget_8cpp.html", null ],
    [ "widget.h", "widget_8h.html", "widget_8h" ]
];